C++ compiler version:
Hazelcast Cpp client version:
Hazelcast server version:
Number of the clients:
Cluster size, i.e. the number of Hazelcast cluster members:
OS version (Windows/Linux/OSX):

Please attach relevant logs and files for client and server side.

#### Expected behaviour


#### Actual behaviour


#### Steps to reproduce the behaviour