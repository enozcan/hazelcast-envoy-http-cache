Generate boost includes using:

bcp smart_ptr date_time regex property_tree
