/*
 * Copyright (c) 2008-2019, Hazelcast, Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include <hazelcast/client/HazelcastClient.h>
#include <hazelcast/client/config/ClientConnectionStrategyConfig.h>
#include <hazelcast/client/LifecycleListener.h>

class DisconnectedListener : public hazelcast::client::LifecycleListener {
public:
    DisconnectedListener() : disconnectedLatch(1), connectedLatch(1) {}

    virtual void stateChanged(const hazelcast::client::LifecycleEvent &lifecycleEvent) {
        if (lifecycleEvent.getState() == hazelcast::client::LifecycleEvent::CLIENT_DISCONNECTED) {
            disconnectedLatch.countDown();
        } else if (lifecycleEvent.getState() == hazelcast::client::LifecycleEvent::CLIENT_CONNECTED) {
            connectedLatch.countDown();
        }
    }

    void waitForDisconnection() {
        disconnectedLatch.await();
    }

    bool awaitReconnection(int seconds) {
        return connectedLatch.await(seconds);
    }
private:
    hazelcast::util::CountDownLatch disconnectedLatch;
    hazelcast::util::CountDownLatch connectedLatch;
};


int main() {
    hazelcast::client::ClientConfig config;

    /**
     * How a client reconnect to cluster after a disconnect can be configured. This parameter is used by default strategy and
     * custom implementations may ignore it if configured.
     * default value is {@link ReconnectMode#ON}
     *
     * This example forces client NOT to reconnect if it ever disconnects from the cluster.
     */
    config.getConnectionStrategyConfig().setReconnectMode(hazelcast::client::config::ClientConnectionStrategyConfig::OFF);

    hazelcast::client::HazelcastClient hz(config);

    hazelcast::client::IMap<int, int> map = hz.getMap<int, int>("MyMap");

    map.put(1, 100);

    DisconnectedListener listener;
    hz.addLifecycleListener(&listener);

    // Please shut down the cluster at this point.
    listener.waitForDisconnection();

    std::cout << "Client is disconnected from the cluster now." << std::endl;

    if (!listener.awaitReconnection(10)) {
        std::cout << "The client did not connect to the cluster 10 seconds after disconnection as expected." << std::endl;
    }

    hz.shutdown();
    std::cout << "Finished" << std::endl;

    return 0;
}

